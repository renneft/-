"""Rebuild the standalone index.html using only Python's standard library."""
from pathlib import Path
import base64
root=Path(__file__).resolve().parent
source=root/'src'
page=(source/'shell.html').read_text(encoding='utf-8')
for token,name in [('STYLE','style.css'),('MODEL','model.js'),('CORRECTIONS','corrections.js'),('APP','app.js')]:
    page=page.replace('/*'+token+'*/',(source/name).read_text(encoding='utf-8'))
page=page.replace('/*EMBLEM*/','data:image/png;base64,'+base64.b64encode((source/'gubkin-emblem.png').read_bytes()).decode())
(root/'index.html').write_text(page,encoding='utf-8')
print('Built',root/'index.html')
