'use strict';
const assert=require('assert'),fs=require('fs'),vm=require('vm'),path=require('path');
const R=require('../src/model.js'),M=R.create();
assert(Math.abs(R.E1(1)-.2193839343955203)<1e-13);
assert(Math.abs(R.E1(.1)-1.8229239584193906)<1e-13);
const fixed=M.finite({bound:'fixed'}),closed=M.finite({bound:'closed'});
assert(Math.abs(fixed.ps.at(-1)[1]-M.stationary(M.P.rw))<.02);
const expectedMean=M.P.pi-M.P.q*M.P.B*M.P.T/24/(Math.PI*(M.P.re**2-M.P.rw**2)*M.P.h*M.P.phi*M.P.ct);
assert(Math.abs(closed.means.at(-1)[1]-expectedMean)<1e-7,'mass balance');
const draw=M.P.q*M.coeff()*(Math.log(M.P.re/M.P.rw)-.75);
assert(Math.abs(closed.means.at(-1)[1]-closed.ps.at(-1)[1]-draw)<.02);
const fine=M.finite({bound:'closed',n:300,steps:1440});
assert(Math.abs(closed.ps.at(-1)[1]-fine.ps.at(-1)[1])<.02);
const raised=R.create({pe:270}).finite({bound:'fixed'});
assert(Math.abs(raised.ps.at(-1)[1]-R.create({pe:270}).stationary(.1))<.03);
const pressure=M.finite({bound:'closed',control:'pressure'});
assert(pressure.ps.every(p=>p[1]===200));assert(pressure.qs.at(-1)[1]<.1);
const stop=M.finite({control:'pressure',stop:72});
assert(stop.qs.filter(p=>p[0]>72).every(p=>p[1]===0));assert(stop.ps.at(-1)[1]>200);
assert.throws(()=>R.create({rw:3,rs:2}));
const ctx=vm.createContext({RadialModel:R,console,document:{querySelector:()=>null}});
vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/corrections.js'),'utf8'),ctx);
vm.runInContext(fs.readFileSync(path.join(__dirname,'../src/app.js'),'utf8').replace(/init\(\);\s*$/,''),ctx);
const ids=vm.runInContext('tasks.map(t=>t[0])',ctx);let graphs=0;
for(const id of ids){
 const config={task:id,P:{...R.defaults},bound:id.startsWith('1.')||id.startsWith('2.2')?'fixed':id.startsWith('2.3')?'closed':'infinite',quality:'normal',times:[1,10,50],compare:['2.4.1','2.5.1'].includes(id),historyQ:[[0,50],[24,80],[72,20],[120,0]],historyP:[[0,220],[24,200],[72,230],[120,240]]};
 ctx.config=config;const out=vm.runInContext('compute(config)',ctx);
 for(const p of out.items.filter(i=>i.type==='plot')){graphs++;assert(p.series.length);for(const s of p.series){assert(s.data.length>1,id);assert(s.data.filter(p=>p[0]>0).length>1,id+' log plot needs two positive x values');assert(s.data.every(p=>p.every(Number.isFinite)),id+' nonfinite');}}
}
// Non-default geometry, horizon and profile times must propagate into the solver.
const changed=R.create({k:75,q:20,re:450,T:36,stop:12});const f=changed.finite({bound:'fixed',targets:[.5,7,36]});
assert.deepStrictEqual(f.snap.map(s=>s.t),[.5,7,36]);assert(f.ps.at(-1)[0]===36);assert(f.snap.every(s=>s.points.at(-1)[0]===450));
console.log(JSON.stringify({passed:true,tasks:ids.length,graphSets:graphs,steadyError:Math.abs(fixed.ps.at(-1)[1]-M.stationary(.1)),massBalanceError:Math.abs(closed.means.at(-1)[1]-expectedMean)},null,2));
