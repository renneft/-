/* Радиальная фильтрация. Все входы в практических единицах, перевод в СИ явный.
 * Автор приложения: Юсифов Р.Р., РС-22-10. Численная схема: конечные объёмы,
 * логарифмическая сетка, backward Euler, прогонка трёхдиагональной системы.
 * Положительный q — отбор на поверхности. Давление — абсолютное, атм.
 */
'use strict';
const RadialModel = (() => {
  const defaults = {pi:250,pe:250,k:40,ks:10,q:50,B:1.2,mu:1,h:10,phi:.2,ct:1e-5,rw:.1,re:240,rs:2,T:240,pwf:200,S:2,stop:72};
  const units = {atm:101325,md:9.869233e-16,cp:.001,day:86400,hour:3600};
  function grid(a,b,n=240) { return Array.from({length:n},(_,i)=>a*(b/a)**(i/(n-1))); }
  function E1(x) {
    if(x<=0) return Infinity;
    if(x>740) return 0;
    if(x<=1) {let sum=0,term=1;for(let n=1;n<200;n++){term*=-x/n;const add=term/n;sum+=add;if(Math.abs(add)<1e-16)break;}return -.5772156649015329-Math.log(x)-sum;}
    let b=x+1,c=1e300,d=1/b,h=d;
    for(let i=1;i<200;i++){const a=-i*i;b+=2;d=1/(a*d+b);c=b+a/c;const z=c*d;h*=z;if(Math.abs(z-1)<1e-14)break;}return h*Math.exp(-x);
  }
  function valueAt(history,t,ramp=false) {
    let a=history[0];
    for(let i=1;i<history.length;i++){const b=history[i];if(t<b[0])return ramp?a[1]+(b[1]-a[1])*(t-a[0])/(b[0]-a[0]):a[1];a=b;}return a[1];
  }
  function validate(P) {
    const errors=[];
    for(const [key,v] of Object.entries(P))if(!Number.isFinite(v))errors.push(`Параметр ${key}: требуется конечное число.`);
    for(const key of ['k','ks','B','mu','h','ct','rw','re','rs','T','pi','pe','pwf'])if(!(P[key]>0))errors.push(`${key} должен быть положительным.`);
    if(!(P.phi>0&&P.phi<1))errors.push('Пористость должна быть больше 0 и меньше 1.');
    if(!(P.rw<P.rs&&P.rs<P.re))errors.push('Радиусы должны удовлетворять условию rw < rs < re.');
    if(P.T<.0001||P.T>1e6)errors.push('Время расчёта: от 0,0001 до 1 000 000 ч.');
    if(P.re/P.rw>1e9)errors.push('Отношение re/rw должно быть не больше 10⁹.');
    return errors;
  }
  function create(input={}) {
    const P={...defaults,...input};const errors=validate(P);if(errors.length)throw Error(errors.join('\n'));
    // alpha: m²/h; C: atm/(surface m³/day). Rounding is avoided.
    const alpha=(k=P.k)=>k*units.md/(P.phi*P.mu*units.cp*(P.ct/units.atm))*units.hour;
    const coeff=(k=P.k)=>P.B*P.mu*units.cp/(units.day*2*Math.PI*k*units.md*P.h*units.atm);
    const kernel=(r,t,k=P.k)=>t<=0?0:.5*E1(r*r/(4*alpha(k)*t));
    function integrated(r,t,k=P.k){if(t<=0)return 0;const b=r*r/(4*alpha(k));return .5*((t+b)*E1(b/t)-t*Math.exp(-b/t));}
    function stationary(r,{k=P.k,S=0,zone=true}={}) {
      const extra=zone?S*Math.max(0,Math.log(P.rs/Math.max(r,P.rw)))/Math.log(P.rs/P.rw):0;
      return P.pe-P.q*coeff(k)*(Math.log(P.re/r)+extra);
    }
    function linePressure(r,t,{k=P.k,history=[[0,P.q]],ramp=false}={}) {
      let d=history[0][1]*kernel(r,t,k),prev=history[0][1];
      if(!ramp)for(let i=1;i<history.length;i++){d+=(history[i][1]-prev)*kernel(r,t-history[i][0],k);prev=history[i][1];}
      else {let oldSlope=0;for(let i=0;i<history.length;i++){const slope=i<history.length-1?(history[i+1][1]-history[i][1])/(history[i+1][0]-history[i][0]):0;d+=(slope-oldSlope)*integrated(r,t-history[i][0],k);oldSlope=slope;}}
      return P.pi-coeff(k)*d;
    }
    function timeGrid(history,targets,steps,stop=Infinity) {
      const eps=Math.min(1e-6,P.T*1e-7),events=[...history.map(s=>s[0]),...(Number.isFinite(stop)?[stop]:[])];
      return [0,...grid(eps,P.T,260),...Array.from({length:steps+1},(_,i)=>P.T*i/steps),...targets,...events.flatMap(t=>[t,...grid(eps,Math.min(P.T/100,.1),24).map(dt=>t+dt)])]
        .filter(t=>t>=0&&t<=P.T).sort((a,b)=>a-b).filter((t,i,a)=>!i||t-a[i-1]>eps*1e-4);
    }
    function lineRun({history=[[0,P.q]],ramp=false,k=P.k,targets=[P.T*.01,P.T*.1,P.T]}={}) {
      const times=timeGrid(history,targets,480),o={history,ramp,k};
      // Include both sides of rate jumps to render the imposed history faithfully.
      const qt=[...times,...history.filter(s=>s[0]>0).map(s=>s[0]-Math.min(1e-8,P.T*1e-10))].sort((a,b)=>a-b);
      return {ps:times.map(t=>[t,linePressure(P.rw,t,o)]),qs:qt.map(t=>[t,valueAt(history,t,ramp)]),snap:targets.map(t=>({t,points:grid(P.rw,P.re).map(r=>[r,linePressure(r,t,o)])})),method:'Точное решение линейного стока E₁'};
    }
    function finite({k=P.k,S=0,skin='zone',bound='infinite',control='rate',history=null,ramp=false,stop=Infinity,targets=[P.T*.01,P.T*.1,P.T],n=180,steps=720}={}) {
      const a=alpha(k),C=coeff(k),R=bound==='infinite'?Math.max(P.re,12*Math.sqrt(a*P.T)):P.re;
      if(skin==='zone'&&1+S/Math.log(P.rs/P.rw)<=0)throw Error('Скин этой зоны требует отрицательной проницаемости. Уменьшите |S| или увеличьте rs.');
      const r0=skin==='ideal'&&S<0?P.rw*Math.exp(-S):P.rw;
      if(!(r0<R))throw Error('Эффективный радиус должен быть меньше радиуса области расчёта.');
      const edges=grid(r0,R,n+1),r=edges.slice(0,n).map((x,i)=>Math.sqrt(x*edges[i+1]));
      function resistance(x,y){let z=Math.log(y/x);if(skin==='zone')z+=S/Math.log(P.rs/P.rw)*Math.max(0,Math.log(Math.min(y,P.rs)/Math.min(x,P.rs)));return C*z;}
      const g=r.slice(1).map((_,i)=>1/resistance(r[i],r[i+1])),gw=1/(resistance(r0,r[0])+(skin==='ideal'&&S>0?C*S:0)),ge=bound==='closed'?0:1/resistance(r.at(-1),R);
      const outer=bound==='fixed'?P.pe:P.pi;
      const cap=r.map((_,i)=>(edges[i+1]**2-edges[i]**2)/(2*a*C));
      const u=new Float64Array(n),H=history??[[0,control==='rate'?P.q:P.pwf]],times=timeGrid(H,targets,steps,stop);
      const ps=[],qs=[],snap=[],means=[];let old=0;
      const targetSet=new Set(targets);
      for(let j=1;j<times.length;j++){
        const t=times[j],dt=t-old,closedWell=old>=stop-1e-12,rate=control==='rate'||closedWell;
        const val=closedWell?0:valueAt(H,ramp?t:(old+t)/2,ramp);
        const lo=new Float64Array(n),diag=new Float64Array(n),up=new Float64Array(n),rhs=new Float64Array(n);
        for(let i=0;i<n;i++){const gl=i?g[i-1]:0,gr=i<n-1?g[i]:ge;lo[i]=-gl;up[i]=i<n-1?-gr:0;diag[i]=cap[i]/dt+gl+gr;rhs[i]=cap[i]/dt*u[i];}
        rhs[n-1]+=ge*(P.pi-outer);
        if(rate)rhs[0]+=val;else{diag[0]+=gw;rhs[0]+=gw*(P.pi-val);}
        for(let i=1;i<n;i++){const f=lo[i]/diag[i-1];diag[i]-=f*up[i-1];rhs[i]-=f*rhs[i-1];}
        u[n-1]=rhs[n-1]/diag[n-1];for(let i=n-2;i>=0;i--)u[i]=(rhs[i]-up[i]*u[i+1])/diag[i];
        const q=rate?val:gw*(P.pi-val-u[0]),pw=rate?P.pi-u[0]-q/gw:val;
        ps.push([t,pw]);qs.push([t,q]);old=t;
        const mean=P.pi-u.reduce((sum,v,i)=>sum+v*cap[i],0)/cap.reduce((s,v)=>s+v,0);means.push([t,mean]);
        if(targetSet.has(t))snap.push({t,points:[[r0,pw],...r.map((x,i)=>[x,P.pi-u[i]]),[R,bound==='closed'?P.pi-u[n-1]:outer]],average:mean});
      }
      if(ps.some(p=>!Number.isFinite(p[1])))throw Error('Расчёт неустойчив для выбранных параметров. Проверьте масштабы и геометрию.');
      return {ps,qs,snap,means,method:`Конечные объёмы: ${n} ячеек, ${times.length-1} шагов`,R};
    }
    return {P,alpha,coeff,kernel,integrated,stationary,linePressure,lineRun,finite};
  }
  return {defaults,units,grid,E1,valueAt,validate,create};
})();
if(typeof module!=='undefined')module.exports=RadialModel;
