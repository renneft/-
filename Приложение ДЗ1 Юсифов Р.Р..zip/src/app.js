'use strict';
// UI and assignment presets. No requests to remote services, no runtime dependencies.
const $=s=>document.querySelector(s), esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const tasks=[
 ['1.1.1','Однородный стационарный пласт'],['1.1.2','Композитный пласт'],['1.1.3','Стационарный скин-фактор'],['1.1.4','Вопросы к стационарной модели'],
 ['2.1.1','Постоянный дебит'],['2.1.2','Скин-фактор'],['2.2.1','Постоянный дебит'],['2.2.2','Скин-фактор'],['2.2.3','Стационарный предел'],
 ['2.3.1','Постоянный дебит'],['2.3.2','Скин-фактор'],['2.3.3','Псевдоустановившийся режим'],['2.4.1','Профили давления'],['2.4.2','Закон Дарси и профиль'],
 ['2.5.1','Постоянное забойное давление'],['2.6.1','Запуск и остановка'],['2.6.2','Падение и восстановление'],['2.6.3','Ступенчатые истории'],['2.7.1','Плавные истории']];
const groups={'1.1':'Стационарный приток','2.1':'Бесконечный пласт','2.2':'Питаемый контур','2.3':'Замкнутый пласт','2.4':'Давление в пласте','2.5':'Управление давлением','2.6':'Суперпозиция','2.7':'Плавные изменения'};
const labels={pi:'Начальное pi, атм',pe:'На контуре pe, атм',k:'Проницаемость k, мД',ks:'Проницаемость зоны ks, мД',q:'Дебит q, м³/сут',B:'Коэффициент B, м³/м³',mu:'Вязкость μ, сП',h:'Толщина h, м',phi:'Пористость φ, доля',ct:'Сжимаемость ct, атм⁻¹',rw:'Радиус rw, м',re:'Радиус контура re, м',rs:'Радиус зоны rs, м',T:'Время расчёта T, ч',pwf:'Заданное pwf, атм',S:'Модуль скина |S|',stop:'Остановка tp, ч'};
const BN={infinite:'Бесконечный пласт',fixed:'Постоянное давление',closed:'Непротекание'};
const COL=['#1764bf','#c58a2d','#d35759','#318e81','#7c5ab6'];
const fmt=v=>Number(v.toPrecision(5)).toLocaleString('ru-RU',{maximumFractionDigits:5});
let task='1.1.1',result=null,lastConfig=null,dirty=false;
const formulas={
 darcy:'qB = (2πkh/μ) r ∂p/∂r;  A = qBμ/(2πkh)',
 ss:'p(r) = pₑ − A ln(rₑ/r);  q = 2πkh(pₑ − p_wf) / [Bμ ln(rₑ/rw)]',
 skin:'S = (k/ks − 1) ln(rs/rw); Δp_skin = AS; r_eff = rw exp(−S)',
 pde:'∂p/∂t = α (1/r) ∂/∂r(r ∂p/∂r); α = k/(φμct)',
 ei:'p(r,t) = pi − A E₁[r²/(4αt)]/2; E₁(x) = −Ei(−x)',
 log:'p_D ≈ ½[ln(4t_D/r_D²) − γ]; p_D = (pi − p)/A; t_D = αt/rw²; r_D = r/rw',
 fixed:'p(rₑ,t) = pₑ',closed:'∂p/∂r |rₑ = 0',
 pressure:'p(rw,t) = pзад(t); q(t) = [2πkh/(Bμ)] rw ∂p/∂r |rw',
 step:'pi − p(r,t) = [Bμ/(2πkh)] Σ Δqⱼ g(r,t − tⱼ); g(r,t) = ½E₁[r²/(4αt)]',
 ramp:'pi − p = [Bμ/(2πkh)] [q₀g(t) + Σ Δaⱼ J(t − tⱼ)]; J(r,t) = ½[(t + β)E₁(β/t) − t exp(−β/t)]; β = r²/(4α)',
 mean:'p_mean = [2/(rₑ² − rw²)] ∫ᵣwʳᵉ p(r) r dr',
 pss:'p_mean − p_wf ≈ A[ln(rₑ/rw) − ¾ + S]; dp_mean/dt = −qB/[φct πh(rₑ² − rw²)]'
};
function init(){
 $('#fields').innerHTML=Object.entries(labels).map(([key,label])=>`<label class="field">${mathHTML(esc(label))}<input id="p-${key}" name="${key}" type="number" step="any" value="${RadialModel.defaults[key]}" required></label>`).join('');
 $('#nav').innerHTML=tasks.map(([id,title],i)=>`${!i||tasks[i-1][0].slice(0,3)!==id.slice(0,3)?`<div class="navlabel">${id.slice(0,3)} · ${groups[id.slice(0,3)]}</div>`:''}<button class="navitem" data-task="${id}"><span>${id}</span>${title}</button>`).join('');
 $('#nav').onclick=e=>{const b=e.target.closest('[data-task]');if(b)selectTask(b.dataset.task);};
 $('#params').onsubmit=e=>{e.preventDefault();calculate();};$('#reset').onclick=()=>{setFields(RadialModel.defaults);selectTask(task);};
 document.querySelectorAll('.workbench input,.workbench select,.workbench textarea').forEach(el=>el.addEventListener('input',()=>{dirty=true;status('Параметры изменены. Нажмите «Построить графики», чтобы обновить результаты.','warn');}));
 $('#scale').onchange=()=>{if(result)renderResult();};
 $('#save').onclick=saveProject;$('#load').onclick=()=>$('#file').click();$('#file').onchange=loadProject;
 $('#print').onclick=()=>{if(dirty){status('Сначала постройте графики с новыми параметрами.','warn');return;}window.print();};
 $('#csvall').onclick=()=>{if(result)download('DZ1_'+task+'_all.csv',csv(result.items.filter(x=>x.type==='plot')),'text/csv;charset=utf-8');};
 $('#help-open').onclick=()=>$('#help').showModal();$('#help-close').onclick=()=>$('#help').close();
 $('#mobile-nav').onclick=()=>{$('#nav').classList.toggle('open');$('#mobile-nav').setAttribute('aria-expanded',$('#nav').classList.contains('open'));};
 window.addEventListener('hashchange',()=>{const id=location.hash.slice(1);if(id!==task&&tasks.some(t=>t[0]===id))selectTask(id);});
 const initial=location.hash.slice(1);selectTask(tasks.some(t=>t[0]===initial)?initial:task);
}
function setFields(P){for(const key of Object.keys(labels))$('#p-'+key).value=P[key];}
function selectTask(id){
 task=id;location.hash=id;$('#nav').classList.remove('open');
 document.querySelectorAll('[data-task]').forEach(b=>b.classList.toggle('active',b.dataset.task===id));
 $('#chapter').textContent='ДЗ1 / Пункт '+id;$('#title').textContent=tasks.find(t=>t[0]===id)[1];$('#subtitle').textContent=groups[id.slice(0,3)]+' · параметры можно менять';
 const P=Object.fromEntries(Object.keys(labels).map(k=>[k,Number($('#p-'+k).value)])),T=P.T||240;
 $('#boundary').value=id.startsWith('1.')||id.startsWith('2.2')?'fixed':id.startsWith('2.3')?'closed':'infinite';
 const prescribed=id.startsWith('1.')||['2.2.3','2.3.3','2.4.2'].includes(id);$('#boundary').disabled=prescribed;
 $('#compare').checked=['2.4.1','2.5.1'].includes(id);$('#compare').disabled=!['2.4.1','2.5.1'].includes(id);
 $('#times').value=[T/240,T/24,T*5/24].map(x=>Number(x.toPrecision(6))).join('; ');
 const ramp=id==='2.7.1';
 $('#historyQ').value=[[0,ramp?0:P.q],[T*.1,ramp?P.q:1.6*P.q],[T*.3,ramp?1.6*P.q:.4*P.q],[T*.5,0]].map(r=>r.map(x=>+x.toPrecision(8)).join('; ')).join('\n');
 $('#historyP').value=[[0,ramp?P.pi:P.pi-.6*(P.pi-P.pwf)],[T*.1,ramp?P.pi-.6*(P.pi-P.pwf):P.pwf],[T*.3,ramp?P.pwf:P.pi-.4*(P.pi-P.pwf)],[T*.5,ramp?P.pi:P.pi-.2*(P.pi-P.pwf)]].map(r=>r.map(x=>+x.toPrecision(8)).join('; ')).join('\n');
 calculate();
}
function parseHistory(text,T){
 const rows=text.trim().split(/\n+/).map((line,i)=>{const v=line.trim().split(/[;\s]+/).filter(Boolean).map(s=>Number(s.replace(',','.')));if(v.length!==2||v.some(x=>!Number.isFinite(x)))throw Error(`История, строка ${i+1}: введите время; значение.`);return v;});
 if(rows.length>30)throw Error('В истории допускается не больше 30 узлов.');
 if(rows[0][0]!==0)throw Error('Первый узел истории должен начинаться в t = 0.');
 if(rows.some((r,i)=>r[0]<0||r[0]>T||(i&&r[0]<=rows[i-1][0])))throw Error('Времена истории должны строго возрастать от 0 до T.');return rows;
}
function readConfig(){
 for(const key of Object.keys(labels))if(!$('#p-'+key).value.trim())throw Error(`Заполните поле «${labels[key]}».`);
 const P=Object.fromEntries(Object.keys(labels).map(k=>[k,Number($('#p-'+k).value)]));
 const errs=RadialModel.validate(P);if(errs.length)throw Error(errs.join(' '));
 const times=$('#times').value.split(';').map(s=>Number(s.trim().replace(',','.')));
 if(times.length>8||!times.length||times.some(t=>!Number.isFinite(t)||t<=0||t>P.T))throw Error('Укажите от 1 до 8 моментов профилей: 0 < t ≤ T, разделитель — точка с запятой.');
 const stopTask=['2.6.1','2.6.2'].includes(task);if(stopTask&&!(P.stop>0&&P.stop<P.T))throw Error('Время остановки должно быть больше 0 и меньше T.');
 const historyTask=['2.6.3','2.7.1'].includes(task),Hq=historyTask?parseHistory($('#historyQ').value,P.T):[[0,P.q]],Hp=historyTask?parseHistory($('#historyP').value,P.T):[[0,P.pwf]];
 if(Hp.some(r=>r[1]<=0))throw Error('Заданное абсолютное давление в истории должно быть положительным.');
 return {task,P,bound:$('#boundary').value,quality:$('#quality').value,times:[...new Set(times)].sort((a,b)=>a-b),compare:$('#compare').checked,historyQ:Hq,historyP:Hp,rawQ:$('#historyQ').value,rawP:$('#historyP').value,scale:$('#scale').value};
}
function status(message,type=''){const el=$('#status');el.textContent=message;el.className='status '+type;}
async function calculate(){
 $('#calculate').disabled=true;status('Расчёт модели…');
 await new Promise(resolve=>setTimeout(resolve,20));
 try{const config=readConfig();const start=performance.now();const next=compute(config);result=next;lastConfig=config;dirty=false;renderScheme(config);renderResult();
  const neg=next.items.filter(i=>i.type==='plot'&&i.y.includes('атм')).some(i=>i.series.some(s=>s.data.some(d=>d[1]<0)));
  const message=`Готово за ${((performance.now()-start)/1000).toFixed(2)} с. ${next.items.filter(x=>x.type==='plot').length} наборов графиков. `+(neg?'Есть отрицательные абсолютные давления: выбранный режим выходит за область применимости модели. Уменьшите отбор или время.':'Наведите указатель на график, чтобы увидеть значения.');status(message,neg?'warn':'');
 }catch(e){dirty=true;result=null;$('#plots').innerHTML='<div class="empty">Исправьте параметры и повторите расчёт.</div>';$('#summary').textContent='Расчёт не выполнен';$('#explain').textContent='';$('#formulas').textContent='';$('#scheme').innerHTML='';$('#scheme-note').textContent='Схема появится после корректного расчёта.';status(e.message,'error');}finally{$('#calculate').disabled=false;}
}
function compute(c){
 const {P,task:id,bound}=c,M=RadialModel.create(P),G=RadialModel.grid,items=[],S=(name,data)=>({name,data}),A=P.q*M.coeff(),radius=G(P.rw,P.re),absS=Math.abs(P.S);
 let explanation='',eqs=[],method=new Set();const cache=new Map();
 function run(o={}){const key=JSON.stringify(o);if(!cache.has(key)){const opts={targets:c.times,n:c.quality==='fine'?300:180,steps:c.quality==='fine'?1440:720,...o};const exact=opts.exact&&bound==='infinite';const r=exact?M.lineRun(opts):M.finite({bound,...opts});cache.set(key,r);method.add(r.method);}return cache.get(key);}
 const plot=(title,series,x='Время t, ч',y='Давление p, атм',note='')=>items.push({type:'plot',title,series,x,y,note});
 const question=(title,text,eq='')=>items.push({type:'question',title,text,eq});
 const profiles=(res)=>res.snap.map(s=>{const data=s.points.filter(p=>p[0]<=P.re);if(data.length&&data.at(-1)[0]<P.re&&s.points.at(-1)[0]>P.re)data.push([P.re,interpolate(s.points,P.re)]);return S(`t = ${fmt(s.t)} ч`,data);});
 const bc=bound==='fixed'?formulas.fixed:bound==='closed'?formulas.closed:'p(r,t) → pi при r → ∞';
 if(id==='1.1.1'){
  plot('Распределение давления: k и 2k',[S(`k = ${fmt(P.k)} мД`,radius.map(r=>[r,M.stationary(r)])),S(`2k = ${fmt(2*P.k)} мД`,radius.map(r=>[r,M.stationary(r,{k:2*P.k})]))],'Радиус r, м');
  explanation='На внешнем контуре обе кривые достигают pe. У скважины давление ниже при положительном отборе. Удвоение проницаемости уменьшает депрессию вдвое. Логарифмический профиль становится прямой на полулогарифмической оси.';eqs=[formulas.ss,formulas.darcy];
 }else if(id==='1.1.2'){
  const skin=(P.k/P.ks-1)*Math.log(P.rs/P.rw),r=[...new Set([...radius,P.rs])].sort((a,b)=>a-b);
  plot('Двухзонный и однородный пласт',[S(`ks = ${fmt(P.ks)}; k = ${fmt(P.k)} мД`,r.map(x=>[x,M.stationary(x,{S:skin})])),S('Однородный пласт',r.map(x=>[x,M.stationary(x)]))],'Радиус r, м');
  explanation='На границе rs давление непрерывно, а производная меняется, поскольку расход сохраняется при изменении проницаемости. В полулогарифмических координатах наклоны участков относятся как k/ks.';eqs=[formulas.darcy,'p(r) = pe − A ln(re/r), r ≥ rs','p(r) = pe − A[ln(re/rs) + (k/ks)ln(rs/r)], rw ≤ r < rs'];
 }else if(id==='1.1.3'){
  if(absS>=Math.log(P.rs/P.rw))throw Error('Для отрицательного скина зоны требуется |S| < ln(rs/rw).');
  for(const s of [absS,-absS])plot(`Зона конечного радиуса · S = ${fmt(s)}`,[S(`S = ${fmt(s)}`,radius.map(r=>[r,M.stationary(r,{S:s})])),S('S = 0',radius.map(r=>[r,M.stationary(r)]))],'Радиус r, м',undefined,`rs = ${fmt(P.rs)} м; ks = ${fmt(P.k/(1+s/Math.log(P.rs/P.rw)))} мД`);
  plot('Сосредоточенный положительный скин',[S('S > 0: перепад на стенке',[[P.rw,M.stationary(P.rw)-absS*A],...radius.map(r=>[r,M.stationary(r)])]),S('S = 0',radius.map(r=>[r,M.stationary(r)]))],'Радиус r, м');
  plot('Отрицательный скин: эффективный радиус',[S(`r_eff = ${fmt(P.rw*Math.exp(absS))} м`,G(P.rw*Math.exp(absS),P.re).map(r=>[r,M.stationary(r)])),S('Исходная скважина',radius.map(r=>[r,M.stationary(r)]))],'Радиус r, м');
  explanation='Положительный скин увеличивает потери давления, отрицательный уменьшает. Зона конечного радиуса меняет профиль только внутри rs. Сосредоточенный скин даёт дополнительный перепад на стенке; идеальный отрицательный скин соответствует увеличению эффективного радиуса. При конечном rw тонкая зона сжимается к rw с сохранением сопротивления.';eqs=[formulas.ss,formulas.skin];
 }else if(id==='1.1.4'){
  question('Как связаны закон Дарси и радиальный профиль? Как выглядит линейный поток?','При постоянном радиальном расходе площадь потока растёт с r, поэтому dp/dr пропорционален 1/r. В канале постоянного сечения градиент постоянен. Ниже показаны профили при одинаковых давлениях на концах.',formulas.darcy);
  plot('Радиальный поток',[S('p(r)',radius.map(r=>[r,M.stationary(r)]))],'Радиус r, м');plot('Линейный поток',[S('p(x)',[0,...G(.001,1)].map(x=>[x,M.stationary(P.rw)+(P.pe-M.stationary(P.rw))*x]))],'Координата x/L');
  question('Как меняется решение в псевдоустановившемся режиме?','В замкнутом пласте среднее давление снижается. Поздние профили имеют одинаковую форму относительно среднего. Если выбранные времена слишком ранние, кривые ещё не совпадают.',formulas.pss);
  const closed=run({bound:'closed'});plot('Замкнутый пласт: давление',profiles(closed),'Радиус r, м');plot('Форма относительно среднего',closed.snap.map(s=>S(`t = ${fmt(s.t)} ч`,s.points.map(([r,p])=>[r,p-s.average]))),'Радиус r, м','Разность p − p_mean, атм');
  question('Как найти среднее давление и поправку к формуле Дюпюи?','Среднее получают интегрированием по площади кольцевых элементов. При re ≫ rw стационарная формула через среднее содержит −½, а псевдоустановившаяся через среднее — −¾. Через контурное давление в псевдоустановившемся режиме поправка −½.',formulas.mean+'; q ≈ 2πkh(p_mean − p_wf)/[Bμ(ln(re/rw) − ½ + S)]');
  const mean=P.pe-A*(.5-P.rw**2*Math.log(P.re/P.rw)/(P.re**2-P.rw**2));plot('Среднее и контурное давление',[S('p(r)',radius.map(r=>[r,M.stationary(r)])),S('Среднее',[[P.rw,mean],[P.re,mean]]),S('Контурное',[[P.rw,P.pe],[P.re,P.pe]])],'Радиус r, м');
  explanation='Каждый вопрос сопровождается отдельными поясняющими графиками. Первое сравнение и среднее — стационарные; временные профили — замкнутый пласт.';eqs=[formulas.ss,formulas.pss];
 }else if(/^2\.[123]\.[12]$/.test(id)){
  const skin=id.endsWith('.2');
  if(skin){if(absS>=Math.log(P.rs/P.rw))throw Error('Для сравнения отрицательного скина требуется |S| < ln(rs/rw).');
   for(const s of [absS,-absS])plot(`Забойное давление · S = ${fmt(s)}`,[S('S = 0',run().ps),S('Конечная зона rs',run({S:s}).ps),S(s>=0?'Сосредоточенный скин':'Эффективный радиус',run({S:s,skin:'ideal'}).ps)]);
  }else{plot('Забойное давление: k и 2k',[S(`k = ${fmt(P.k)} мД`,run({exact:bound==='infinite'}).ps),S(`2k = ${fmt(2*P.k)} мД`,run({exact:bound==='infinite',k:2*P.k}).ps)]);plot('Постоянный дебит',[S('k и 2k',[[0,P.q],[Math.min(1e-6,P.T*1e-6),P.q],[P.T,P.q]])],undefined,'Дебит q, м³/сут');}
  explanation=(bound==='infinite'?'В бесконечном пласте давление продолжает изменяться; при отборе падает. Поздний радиальный режим близок к прямой по ln t.':bound==='fixed'?'Подпитка с контура приводит к стационарному плато. Если pe отличается от pi, дополнительно распространяется возмущение от внешней границы.':'Замкнутый пласт истощается. Позднее среднее и забойное давления падают с одинаковой скоростью; удвоение k меняет перепад, но не темп истощения.')+(skin?' Положительный скин понижает pwf, отрицательный повышает. Ранний отклик конечной зоны отличается от идеализации.':' Удвоение k уменьшает гидравлическое сопротивление и ускоряет распространение возмущения.');
  eqs=[bound==='infinite'&&!skin?formulas.ei:formulas.pde,bc,skin?formulas.skin:formulas.darcy];
 }else if(id==='2.2.3'){
  question('Как решение соотносится со стационарным на поздних временах?','При постоянном pe приток с контура компенсирует отбор. Численный профиль и забойное давление приближаются к решению Дюпюи. Если T мало, расхождение показывает незавершённый переходный процесс.',formulas.ss);
  const r=run({bound:'fixed',targets:[P.T]});plot('Выход на стационарный предел',[S('Численное pwf',r.ps),S('Предел Дюпюи',[[1e-6,M.stationary(P.rw)],[P.T,M.stationary(P.rw)]])]);plot('Поздний профиль',[...profiles(r),S('Стационарный',radius.map(x=>[x,M.stationary(x)]))],'Радиус r, м');explanation='Сравнение выполнено при одинаковых исходных данных и постоянном давлении на контуре.';eqs=[formulas.fixed,formulas.ss];
 }else if(id==='2.3.3'){
  question('Как решение соотносится с псевдоустановившимся на поздних временах?','Давление не стабилизируется: замкнутый пласт истощается. На поздних временах разность среднего и забойного давлений становится постоянной. При re ≫ rw её предел содержит поправку −¾.',formulas.pss);
  const r=run({bound:'closed'}),d=A*(Math.log(P.re/P.rw)-.75),mean=t=>P.pi-2*M.alpha()*A*t/(P.re**2-P.rw**2);
  plot('Забойное и среднее давления',[S('Численное pwf',r.ps),S('Среднее',r.means),S('Позднее приближение',G(P.T*.2,P.T).map(t=>[t,mean(t)-d]))]);plot('Перепад относительно среднего',[S('Численный',r.ps.map(([t,p],i)=>[t,r.means[i][1]-p])),S('Предел',[[1e-6,d],[P.T,d]])],undefined,'Перепад p_mean − pwf, атм');explanation='Предел нанесён для сопоставления; его применимость оценивается по сближению кривых.';eqs=[formulas.closed,formulas.pss];
 }else if(id==='2.4.1'||id==='2.5.1'){
  const cases=(c.compare?['infinite','fixed','closed']:[bound]).map(b=>({b,r:run({bound:b,control:id==='2.5.1'?'pressure':'rate'})}));
  if(id==='2.5.1')plot('Дебит при постоянном pwf',cases.map(({b,r})=>S(BN[b],r.qs)),undefined,'Дебит q, м³/сут');
  for(const {b,r}of cases)plot('Профили · '+BN[b],profiles(r),'Радиус r, м');
  explanation=id==='2.4.1'?'Воронка давления расширяется во времени. Питаемый контур удерживает pe. На непроницаемом контуре производная равна нулю, а давление меняется. Бесконечный пласт показан до выбранного радиуса re, который в этом случае является границей отображения.':'При фиксированном pwf дебит меняется. В бесконечном пласте он постепенно снижается; при подпитке стремится к стационарному значению, в замкнутом пласте — к нулю. Если pwf выше давления пласта, поток меняет знак.';
  eqs=[formulas.pde,id==='2.5.1'?formulas.pressure:formulas.darcy,formulas.fixed,formulas.closed];
 }else if(id==='2.4.2'){
  question('Как закон Дарси объясняет профиль около скважины и на бесконечности?','Около скважины площадь потока мала и градиент велик. Вдали давление стремится к начальному. При нестационарном притоке локальный расход зависит от радиуса: часть отбора обеспечивается упругим расширением.',formulas.darcy+'; ∂p/∂r = (A/r) exp[−r²/(4αt)]');
  const far=G(P.rw,Math.max(P.re,8*Math.sqrt(M.alpha()*Math.max(...c.times)))) ;plot('Распространение возмущения',[...c.times.map(t=>S(`t = ${fmt(t)} ч`,far.map(r=>[r,M.linePressure(r,t)]))),S('Начальное pi',[[P.rw,P.pi],[far.at(-1),P.pi]])],'Радиус r, м');explanation='На этих графиках используется бесконечный пласт и точное решение E₁.';eqs=[formulas.ei,formulas.log];
 }else if(id==='2.6.1'){
  const h=[[0,P.q],[P.stop,0]],targets=[...new Set([...c.times,P.stop,Math.min(P.T,P.stop+(P.T-P.stop)*.02),P.T])].sort((a,b)=>a-b);
  for(const [control,name,r] of [['rate','Управление по дебиту',run({exact:bound==='infinite',history:h,targets})],['pressure','Управление по давлению',run({control:'pressure',stop:P.stop,targets})]]){
   question(name,control==='rate'?`До ${fmt(P.stop)} ч задан q, затем q = 0.`:`До ${fmt(P.stop)} ч задан pwf, затем скважина закрыта: q = 0. Установка pwf = pi не эквивалентна закрытию.`);
   plot('Дебит · '+name,[S('q(t)',r.qs)],undefined,'Дебит q, м³/сут');plot('Забойное давление · '+name,[S('pwf(t)',r.ps)]);plot('Профили · '+name,profiles(r),'Радиус r, м');
  }
  explanation='После остановки давление продолжает перераспределяться. У скважины оно восстанавливается, профиль сглаживается. В замкнутом пласте конечное равновесное давление ниже начального из-за предшествующего отбора.';eqs=[formulas.step,formulas.pressure,bc];
 }else if(id==='2.6.2'){
  const horizon=Math.min(P.stop,P.T-P.stop),dt=G(Math.min(1e-5,horizon*1e-5),horizon);
  const r=run({exact:bound==='infinite',history:[[0,P.q],[P.stop,0]],targets:[P.stop,...dt,...dt.map(t=>P.stop+t)]});
  const at=(t)=>interpolate(r.ps,t),before=at(P.stop);
  plot('Изменение от момента события',[S('Запуск: pi − p(Δt)',dt.map(t=>[t,P.pi-at(t)])),S('Остановка: p(tp + Δt) − p(tp)',dt.map(t=>[t,at(P.stop+t)-before]))],'Время после события Δt, ч','Изменение давления Δp, атм');
  explanation='Для каждой кривой время отсчитывается от своего события. Восстановление зависит от продолжительности предыдущего отбора, поэтому кривые в общем случае не совпадают. Сравнивается общий доступный интервал времени после обоих событий.';eqs=[formulas.step,'Δpвосст = A[g(tp) − g(tp + Δt) + g(Δt)] — для бесконечного пласта'];
 }else{
  const ramp=id==='2.7.1';
  const rq=run({exact:bound==='infinite',history:c.historyQ,ramp}),rp=run({control:'pressure',history:c.historyP,ramp,...(!ramp?{n:300,steps:2880}:{})});
  question('Задана история дебита',ramp?'Между узлами q меняется линейно. В суперпозиции учитываются изменения наклонов.':'Каждый скачок q добавляет отдельный отклик со своим временем отсчёта.');
  plot('Заданный дебит',[S('q(t)',rq.qs)],undefined,'Дебит q, м³/сут');plot('Отклик забойного давления',[S('pwf(t)',rq.ps)]);
  question('Задана история давления','Давление задаётся на внутренней границе, дебит вычисляется. Отрицательный дебит означает закачку. Самые ранние пики после скачков зависят от сетки.');
  plot('Заданное забойное давление',[S('pwf(t)',rp.ps)]);if(ramp)plot('Отклик дебита',[S('q(t)',rp.qs)],undefined,'Дебит q, м³/сут');else{const avg=averageRate(rp.qs,P.T);plot('Отклик дебита: среднее за '+fmt(avg.width)+' ч',[S('Средний дебит за предыдущий интервал',avg.data)],undefined,'Средний дебит q, м³/сут','t ≥ '+fmt(avg.width)+' ч; окно усреднения '+fmt(avg.width)+' ч');}
  explanation='Произвольные истории задаются в раскрывающемся блоке параметров. После последнего узла значение сохраняется постоянным. Для конечных границ решение получено из той же линейной задачи фильтрации во времени.';eqs=[ramp?formulas.ramp:formulas.step,formulas.pressure,bc];
 }
 applyReportCorrections(items,c);
 if(id==='2.6.3'){explanation+=' На графике отклика дебита показано скользящее среднее за предыдущий час. При T < 2 ч окно уменьшено до T/2 и указано на графике. История давления остаётся ступенчатой; это не мгновенный дебит. Идеальные скачки сохраняются в модели, усреднение позволяет видеть последующее затухание.';eqs.push('q̄(t) = [V(t) − V(t − Δt)]/Δt; V(t) = ∫₀ᵗ q(τ) dτ');}
 if(/^2\.[123]\.2$/.test(id)){explanation+=' Конечная зона имеет собственный переходный процесс; сосредоточенный скин — идеализированное сопротивление на стенке без разрешения зоны по радиусу. Эффективный радиус для отрицательного скина воспроизводит поздний отклик, но не гарантирует совпадения на ранних временах.';eqs.push('p_wf(t) = p(rw+,t) − AS — для идеального положительного скина');}
 return {items,explanation,eqs,methods:[...method],config:c};
}
function interpolate(points,x){
 if(x<=points[0][0])return points[0][1];if(x>=points.at(-1)[0])return points.at(-1)[1];
 let lo=0,hi=points.length-1;while(hi-lo>1){const mid=(hi+lo)>>1;if(points[mid][0]<=x)lo=mid;else hi=mid;}
 const a=points[lo],b=points[hi];return a[1]+(b[1]-a[1])*(x-a[0])/(b[0]-a[0]);
}
function renderScheme(c){
 const {P}=c,stationary=c.task.startsWith('1.'),comp=c.task==='1.1.2',skin=c.task==='1.1.3'||/^2\.[123]\.2$/.test(c.task),pressure=c.task==='2.5.1';
 const multiple=c.compare||['1.1.4','2.6.1','2.6.3','2.7.1'].includes(c.task);
 const boundary=stationary?'fixed':c.bound;
 const condition=boundary==='fixed'?`p(re) = ${fmt(P.pe)} атм`:boundary==='closed'?'∂p/∂r = 0':'p → pi при r → ∞';
 const well=pressure?`pwf = ${fmt(P.pwf)} атм`:['2.6.3','2.7.1','2.6.1'].includes(c.task)?'q(t) / pwf(t)':`q = ${fmt(P.q)} м³/сут`;
 $('#scheme').innerHTML=`<svg viewBox="0 0 470 230" role="img" aria-label="Схема: ${esc(BN[boundary])}; ${esc(well)}"><defs><marker id="arrow" markerWidth="7" markerHeight="7" refX="5" refY="3" orient="auto"><path d="M0 0L6 3L0 6" fill="#2c6fbd"/></marker></defs><circle cx="155" cy="111" r="89" fill="#edf4fe" stroke="#4579b5" stroke-width="2" ${boundary==='infinite'?'stroke-dasharray="5 6"':''}/>${boundary==='closed'?'<circle cx="155" cy="111" r="94" fill="none" stroke="#4579b5" stroke-width="3"/>':''}${skin||comp?'<circle cx="155" cy="111" r="38" fill="#f5e5c5" stroke="#bd923f" stroke-dasharray="4 3"/>':''}<circle cx="155" cy="111" r="10" fill="#193858"/><path d="M155 28V83 M155 194V140 M72 111H125 M238 111H185" stroke="#2c6fbd" stroke-width="1.8" marker-end="url(#arrow)"/><path d="M165 111H277 M215 48H277" fill="none" stroke="#8096ae"/><text x="285" y="49" font-size="12" fill="#17304e">${esc(condition)}</text><text x="285" y="113" font-size="12" fill="#17304e">${esc(well)}</text><text x="285" y="133" font-size="11" fill="#66778d">rw = ${esc(fmt(P.rw))} м</text><text x="285" y="69" font-size="11" fill="#66778d">${boundary==='infinite'?'re — окно отображения':'re = '+esc(fmt(P.re))+' м'}</text>${skin||comp?`<path d="M183 140L277 171" stroke="#bd923f"/><text x="285" y="174" font-size="11" fill="#8b682c">rs = ${esc(fmt(P.rs))} м</text>`:''}<text x="155" y="220" text-anchor="middle" font-size="11" fill="#66778d">Вид сверху · схема не в масштабе</text></svg>`;
 $('#scheme-note').textContent=`k = ${fmt(P.k)} мД, h = ${fmt(P.h)} м. `+(comp?`Внутри зоны ks = ${fmt(P.ks)} мД. `:skin?`Сравниваются S = ±${fmt(Math.abs(P.S))}, зона и идеализации. `:'')+(multiple?'На графиках сравниваются несколько моделей; их границы и режимы указаны в заголовках. На схеме показана выбранная базовая модель.':'');
 const svg=$('#scheme svg'),flow=svg.querySelector('[marker-end]');
 svg.querySelectorAll('text').forEach(t=>{t.innerHTML=svgMath(esc(t.textContent));});
 const dynamic=['2.6.1','2.6.3','2.7.1'].includes(c.task),inward=pressure?P.pi>=P.pwf:P.q>=0;
 const segments=inward?[[155,28,155,83],[155,194,155,140],[72,111,125,111],[238,111,185,111]]:[[155,83,155,28],[155,140,155,194],[125,111,72,111],[185,111,238,111]];
 flow.outerHTML=segments.map(v=>`<path d="M${v[0]} ${v[1]}L${v[2]} ${v[3]}" stroke="#2c6fbd" stroke-width="1.8" ${dynamic?'stroke-dasharray="4 3"':'marker-end="url(#arrow)"'}/>`).join('');
 if(dynamic)$('#scheme-note').textContent+=' Направление потока зависит от текущего участка истории.';
 const zone=svg.querySelector('[fill="#f5e5c5"]');if(zone)zone.setAttribute('r',10+79*Math.log(P.rs/P.rw)/Math.log(P.re/P.rw));
 $('#printparams').textContent=Object.entries(labels).map(([k,label])=>`${label}: ${fmt(P[k])}`).join(' · ')+` · Граница: ${BN[c.bound]} · Времена: ${c.times.join('; ')} ч`;
}
function renderResult(){
 const root=$('#plots');root.innerHTML='';const scale=$('#scale').value;
 for(const item of result.items){
  if(item.type==='question'){const el=document.createElement('section');el.className='qblock';el.innerHTML=`<h3>${esc(item.title)}</h3><div class="answer-text">${item.textHTML?mathHTML(item.textHTML):esc(item.text)}</div>${item.eqHTML?mathHTML(item.eqHTML):item.eq?`<div class="equation">${mathHTML(esc(item.eq))}</div>`:''}`;root.appendChild(el);continue;}
  const modes=scale==='both'?[false,true]:[scale==='log'];for(const log of modes)root.appendChild(chartCard(item,log));
 }
 $('#summary').textContent=`Пункт ${result.config.task} · ${BN[result.config.bound]} · ${root.querySelectorAll('.plotcard').length} графиков · `+(result.methods.length?result.methods.join(' / '):'Аналитическое решение');
 $('#explain').innerHTML=`<p>${mathHTML(esc(result.explanation))}</p><p class="hint">Оси: давление в атм, время в часах, радиус в метрах, поверхностный дебит в м³/сут. Формулы используют согласованные единицы СИ. Логарифмическая шкала показывает физические значения, положительные времена и радиусы.</p>`;
 $('#formulas').innerHTML=result.eqs.map(s=>`<div class="equation">${mathHTML(esc(s))}</div>`).join('');
}
function niceTicks(lo,hi,n=5){
 const raw=(hi-lo)/n,p=10**Math.floor(Math.log10(raw)),f=raw/p,step=(f<=1?1:f<=2?2:f<=5?5:10)*p;
 const start=Math.ceil(lo/step)*step,out=[];for(let v=start;v<=hi+step*1e-6&&out.length<20;v+=step)out.push(v);return out;
}
function tick(v){if(v!==0&&(Math.abs(v)<.001||Math.abs(v)>=1e5))return v.toExponential(0);return Number(v.toPrecision(4)).toString();}
function chartCard(item,log){
 const card=document.createElement('article');card.className='plotcard';
 const visible=item.series.map(()=>true);let geometry=null;
 card.innerHTML=`<div class="plottools"><button data-save="svg">SVG</button><button data-save="csv">CSV</button></div><h3>${esc(item.title)}</h3><p class="hint">${log?'Полулогарифмические':'Обычные'} координаты${item.note?' · '+esc(item.note):''}</p><div class="plotarea"></div><div class="legend"></div><div class="tooltip"></div><p class="hint">Кружок — начало, квадрат — конец показанного интервала. Цвет — по легенде.</p>`;
 const draw=()=>{
  const active=item.series.map((s,i)=>({...s,index:i,data:s.data.filter(([x,y])=>Number.isFinite(x)&&Number.isFinite(y)&&(!log||x>0))})).filter(s=>visible[s.index]&&s.data.length);
  if(!active.length){card.querySelector('.plotarea').innerHTML='<p class="empty">Нет данных для этой шкалы.</p>';return;}
  // Exclude only the startup singularity for pressure-controlled rate plots.
  const cutoff=item.y.startsWith('Дебит')&&active.some(s=>s.data[0][0]>0)?Math.min(.001,result.config.P.T*1e-4):0;
  if(cutoff)active.forEach(s=>s.data=s.data.filter(d=>d[0]>=cutoff));
  const points=active.flatMap(s=>s.data),f=x=>log?Math.log10(x):x;
  let xmin=Math.min(...points.map(p=>f(p[0]))),xmax=Math.max(...points.map(p=>f(p[0]))),ymin=Math.min(...points.map(p=>p[1])),ymax=Math.max(...points.map(p=>p[1]));
  const pad=(ymax-ymin)*.08||Math.max(1,Math.abs(ymax)*.05);ymin-=pad;ymax+=pad;if(xmin===xmax)xmax=xmin+1;
  if(/^(Дебит|Средний дебит)/.test(item.y)&&points.every(d=>d[1]>=0))ymin=Math.max(0,ymin);
  const W=660,left=73,right=23,top=21,bottom=274,iw=W-left-right,ih=bottom-top;
  const legendRows=Math.ceil(active.length/2),H=338+legendRows*18;
  const X=x=>left+(f(x)-xmin)/(xmax-xmin)*iw,Y=y=>bottom-(y-ymin)/(ymax-ymin)*ih;
  let svg=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(item.title)}. ${esc(item.x)}; ${esc(item.y)}"><title>${esc(item.title)}</title><desc>Юсифов Р.Р. · РС-22-10. ${esc(BN[result.config.bound])}. ${log?'Логарифмическая':'Линейная'} шкала X.</desc><rect width="100%" height="100%" fill="white"/>`;
  for(const y of niceTicks(ymin,ymax)){svg+=`<path d="M${left} ${Y(y)}H${W-right}" stroke="#e5ebf2"/><text x="${left-9}" y="${Y(y)+4}" text-anchor="end" font-size="11" fill="#63748a">${tick(y)}</text>`;}
  let xt=log?Array.from({length:Math.floor(xmax)-Math.ceil(xmin)+1},(_,i)=>Math.ceil(xmin)+i):niceTicks(xmin,xmax);
  if(xt.length>8)xt=xt.filter((_,i)=>i%Math.ceil(xt.length/8)===0);if(xt.length<2)xt=[xmin,xmax];
  for(const x of xt){const val=log?10**x:x;svg+=`<path d="M${X(val)} ${top}V${bottom}" stroke="#edf1f6"/><text x="${X(val)}" y="${bottom+19}" text-anchor="middle" font-size="11" fill="#63748a">${tick(val)}</text>`;}
  svg+=`<path d="M${left} ${top}V${bottom}H${W-right}" fill="none" stroke="#8597ad"/>`;
  for(const s of active){const path=s.data.map((p,j)=>`${j?'L':'M'}${X(p[0]).toFixed(2)} ${Y(p[1]).toFixed(2)}`).join(' ');svg+=`<path d="${path}" fill="none" stroke="${COL[s.index%COL.length]}" stroke-width="2.3" ${s.index%2?'stroke-dasharray="7 4"':''}/>`;}
  for(const s of active){const a=s.data[0],b=s.data.at(-1),r=Math.max(2.4,5-s.index*.4),color=COL[s.index%COL.length];svg+=`<circle class="endpoint start" cx="${X(a[0])}" cy="${Y(a[1])}" r="${r}" fill="none" stroke="${color}" stroke-width="1.5"/><rect class="endpoint end" x="${X(b[0])-r}" y="${Y(b[1])-r}" width="${2*r}" height="${2*r}" fill="none" stroke="${color}" stroke-width="1.5"/>`;}
  svg+=`<text x="${left+iw/2}" y="${bottom+42}" text-anchor="middle" font-size="12" fill="#284761">${svgMath(esc(item.x))}${log?' · лог. шкала':''}</text><text transform="translate(17 ${top+ih/2}) rotate(-90)" text-anchor="middle" font-size="12" fill="#284761">${svgMath(esc(item.y))}</text>`;
  active.forEach((s,i)=>{const x=24+(i%2)*315,y=337+Math.floor(i/2)*18;svg+=`<path d="M${x} ${y-4}h20" stroke="${COL[s.index%COL.length]}" stroke-width="2" ${s.index%2?'stroke-dasharray="6 3"':''}/><circle cx="${x}" cy="${y-4}" r="3" fill="white" stroke="${COL[s.index%COL.length]}"/><rect x="${x+17}" y="${y-7}" width="6" height="6" fill="white" stroke="${COL[s.index%COL.length]}"/><text x="${x+27}" y="${y}" font-size="11" fill="#40566d">${svgMath(esc(s.name))}</text>`;});
  if(cutoff)svg+=`<text x="${W-right}" y="12" text-anchor="end" font-size="10" fill="#63748a">t ≥ ${tick(cutoff)} ч; начальный пик исключён</text>`;
  svg+='<line class="crosshair" x1="0" x2="0" y1="21" y2="274" stroke="#8ba3c1" stroke-dasharray="3 4" visibility="hidden"/></svg>';
  card.querySelector('.plotarea').innerHTML=svg;geometry={left,right,top,bottom,W,H,xmin,xmax,active,iw};
  const sv=card.querySelector('svg');sv.style.fontFamily='Arial, sans-serif';
  sv.onpointermove=e=>{const rect=sv.getBoundingClientRect(),vx=(e.clientX-rect.left)*W/rect.width;if(vx<left||vx>W-right)return;
   const fx=xmin+(vx-left)/iw*(xmax-xmin),x=log?10**fx:fx;const tip=card.querySelector('.tooltip');tip.innerHTML=`<b>${esc(item.x)}: ${esc(fmt(x))}</b><br>`+active.map(s=>`${esc(s.name)}: ${esc(fmt(interpolate(s.data,x)))}`).join('<br>');tip.style.display='block';tip.style.left=Math.min(e.clientX-card.getBoundingClientRect().left+10,Math.max(0,card.clientWidth-270))+'px';tip.style.top=Math.max(15,e.clientY-card.getBoundingClientRect().top-90)+'px';const line=sv.querySelector('.crosshair');line.setAttribute('x1',vx);line.setAttribute('x2',vx);line.setAttribute('visibility','visible');};
  sv.onpointerleave=()=>{card.querySelector('.tooltip').style.display='none';sv.querySelector('.crosshair').setAttribute('visibility','hidden');};
 };
 const legend=card.querySelector('.legend');item.series.forEach((s,i)=>{const b=document.createElement('button');b.innerHTML=`<i style="background:${COL[i%COL.length]}"></i>${mathHTML(esc(s.name))}`;b.title='Скрыть / показать кривую';b.setAttribute('aria-pressed','true');b.onclick=()=>{if(visible[i]&&visible.filter(Boolean).length===1)return;visible[i]=!visible[i];b.classList.toggle('off',!visible[i]);b.setAttribute('aria-pressed',String(visible[i]));draw();};legend.appendChild(b);});
 card.querySelector('[data-save="csv"]').onclick=()=>download(`DZ1_${task}_${item.title}.csv`,csv([item]),'text/csv;charset=utf-8');
 card.querySelector('[data-save="svg"]').onclick=()=>{const svg=card.querySelector('svg').cloneNode(true);svg.querySelector('.crosshair')?.remove();svg.setAttribute('font-family','Arial, sans-serif');download(`DZ1_${task}_${item.title}_${log?'log':'linear'}.svg`,new XMLSerializer().serializeToString(svg),'image/svg+xml;charset=utf-8');};
 draw();return card;
}
function csv(plots){const quote=s=>'"'+String(s).replace(/"/g,'""')+'"';return '\ufeff'+[['График','Кривая','Ось X','Ось Y','X','Y'],...plots.flatMap(p=>p.series.flatMap(s=>s.data.map(([x,y])=>[p.title,s.name,p.x,p.y,x,y])))].map(r=>r.map(quote).join(';')).join('\r\n');}
function download(name,content,type){const url=URL.createObjectURL(new Blob([content],{type})),a=document.createElement('a');a.href=url;a.download=name.replace(/[<>:"/\\|?*]/g,'_');a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function saveProject(){try{const c=readConfig();download('DZ1_project.json',JSON.stringify({format:'gubkin-dz1',version:1,author:'Юсифов Р.Р.',group:'РС-22-10',...c},null,2),'application/json');}catch(e){status(e.message,'error');}}
async function loadProject(){
 const file=$('#file').files[0];if(!file)return;
 try{if(file.size>100000)throw Error('Файл проекта слишком большой.');const c=JSON.parse(await file.text());
  if(c.format!=='gubkin-dz1'||c.version!==1||!tasks.some(t=>t[0]===c.task))throw Error('Это не проект ДЗ1 поддерживаемой версии.');
  if(RadialModel.validate(c.P).length||Object.keys(labels).some(k=>typeof c.P[k]!=='number')||!['infinite','fixed','closed'].includes(c.bound)||!['normal','fine'].includes(c.quality)||!['both','linear','log'].includes(c.scale)||!Array.isArray(c.times)||typeof c.rawQ!=='string'||typeof c.rawP!=='string')throw Error('Некорректные настройки проекта.');
  // Restore all controls before one calculation, including inactive history editors.
  setFields(c.P);task=c.task;location.hash=task;document.querySelectorAll('[data-task]').forEach(b=>b.classList.toggle('active',b.dataset.task===task));
  $('#chapter').textContent='ДЗ1 / Пункт '+task;$('#title').textContent=tasks.find(t=>t[0]===task)[1];$('#subtitle').textContent=groups[task.slice(0,3)]+' · проект загружен';
  $('#boundary').value=c.bound;$('#boundary').disabled=task.startsWith('1.')||['2.2.3','2.3.3','2.4.2'].includes(task);$('#quality').value=c.quality;$('#times').value=c.times.join('; ');$('#compare').checked=!!c.compare;$('#compare').disabled=!['2.4.1','2.5.1'].includes(task);$('#historyQ').value=c.rawQ;$('#historyP').value=c.rawP;$('#scale').value=c.scale;await calculate();
 }catch(e){status('Не удалось открыть проект: '+e.message,'error');}finally{$('#file').value='';}
}
init();
